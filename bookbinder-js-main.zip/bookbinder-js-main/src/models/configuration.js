// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

import { z } from 'zod';
import { PAGE_SIZES } from '../constants';

const commaSeparatedNumberList = z
  .union([z.string(), z.array(z.number())])
  .transform((val) => {
    if (Array.isArray(val)) {
      return val;
    }

    return val.split(/, */);
  })
  .pipe(z.array(z.coerce.number()));

const coercedBoolean = z
  .union([
    z
      .string()
      .toLowerCase()
      .pipe(z.enum(['true', 'false', 'on'])),
    z.boolean(),
  ])
  .transform((val) => val === 'true' || val === 'on' || val === true);

/**
 * @type {<Output=unknown, Def extends (import("zod").ZodTypeDef)=(import("zod").ZodTypeDef), Input=Output>(schema: ZodType<Output, Def, Input>) => ZodType<Output | undefined, Def, Input | undefined>}
 */
const urlSafe = (schema) => schema.optional().catch(() => undefined);

const sourceRotation = urlSafe(
  z.enum(['none', '90cw', '90ccw', 'out_binding', 'in_binding'])
).default('none');

const sewingMarkLocation = urlSafe(z.enum(['all', 'only_out', 'only_in', 'in_n_out'])).default(
  'all'
);

/** @type { keyof typeof import("../constants").PAGE_SIZES } */
const availablePaperSizes = Object.keys(PAGE_SIZES);

const paperSize = urlSafe(z.enum([...availablePaperSizes, 'CUSTOM'])).default('A4');

const paperSizeUnit = urlSafe(z.enum(['pt', 'in', 'cm'])).default('pt');

const printerType = urlSafe(z.enum(['single', 'duplex'])).default('duplex');

const pageLayout = urlSafe(z.enum(['folio', 'quarto', 'octavo', 'sextodecimo'])).default('folio');

const pageScaling = urlSafe(z.enum(['centered', 'lockratio', 'stretch'])).default('lockratio');

const pagePositioning = urlSafe(z.enum(['centered', 'binding_aligned'])).default('centered');

const sigFormat = urlSafe(
  z.enum([
    'booklet',
    'perfect',
    'standardsig',
    'customsig',
    '1_3rd',
    'A7_2_16s',
    '8_zine',
    'a_3_6s',
    'a9_3_3_4',
    'a_4_8s',
    'a10_6_10s',
  ])
).default('standardsig');

const wackySpacing = urlSafe(z.enum(['wacky_pack', 'wacky_gap'])).default('wacky_pack');

const printFile = urlSafe(z.enum(['aggregated', 'signatures', 'both'])).default('both');

export const schema = z.object({
  printFile,
  sourceRotation,
  rotatePage: urlSafe(coercedBoolean).default(false),
  paperSize,
  paperSizeUnit,
  printerType,
  paperRotation90: urlSafe(coercedBoolean).default(false),
  pageLayout,
  cropMarks: urlSafe(coercedBoolean).default(false),
  cutMarks: urlSafe(coercedBoolean).default(false),
  pdfEdgeMarks: urlSafe(coercedBoolean).default(false),
  sigOrderMarks: urlSafe(coercedBoolean).default(false),
  pageScaling,
  pagePositioning,
  mainForeEdgePaddingPt: urlSafe(z.coerce.number()).default(0),
  bindingEdgePaddingPt: urlSafe(z.coerce.number()).default(0),
  topEdgePaddingPt: urlSafe(z.coerce.number()).default(0),
  bottomEdgePaddingPt: urlSafe(z.coerce.number()).default(0),
  sigFormat,
  sigLength: urlSafe(z.coerce.number()).default(4), // Specific to standard
  customSigLength: urlSafe(commaSeparatedNumberList).default(null), // Specific to custom.
  foreEdgePaddingPt: urlSafe(z.coerce.number()).default(0), // specific to wacky small
  wackySpacing, // specific to wacky small
  flyleafs: urlSafe(z.coerce.number()).default(1),

  sewingMarksEnabled: urlSafe(coercedBoolean).default(false),
  sewingMarkLocation,
  sewingMarksMarginPt: urlSafe(z.coerce.number()).default(72),
  sewingMarksAmount: urlSafe(z.coerce.number()).default(3),
  sewingMarksTapeWidthPt: urlSafe(z.coerce.number()).default(36),

  paperSizeCustomWidth: urlSafe(z.coerce.number()).default(0),
  paperSizeCustomHeight: urlSafe(z.coerce.number()).default(0),
});

/** @typedef {z.infer<typeof schema>} Configuration */

export const defaultConfig = schema.parse({});
